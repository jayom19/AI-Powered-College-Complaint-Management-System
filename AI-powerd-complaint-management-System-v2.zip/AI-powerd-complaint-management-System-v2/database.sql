-- AI-Powered College Complaint Management System
-- Database Schema for MySQL (Port 3307)
CREATE DATABASE IF NOT EXISTS `college_complaint1` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `college_complaint1`;

-- Table: users (Students)
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` VARCHAR(50) NOT NULL UNIQUE,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: admins
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `role` VARCHAR(50) DEFAULT 'Admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: complaints
CREATE TABLE IF NOT EXISTS `complaints` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` VARCHAR(50) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `ai_predicted_category` VARCHAR(100) DEFAULT NULL,
  `department` VARCHAR(100) DEFAULT NULL,
  `priority` ENUM('Low', 'Medium', 'High') DEFAULT 'Medium',
  `sentiment` ENUM('Positive', 'Neutral', 'Negative') DEFAULT 'Neutral',
  `ai_summary` TEXT DEFAULT NULL,
  `attachment` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('Submitted', 'In Progress', 'Resolved', 'Rejected') DEFAULT 'Submitted',
  `ai_status` ENUM('Pending', 'Completed', 'Failed') DEFAULT 'Pending',
  `created_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolved_date` DATETIME DEFAULT NULL,
  INDEX (`student_id`),
  INDEX (`status`),
  INDEX (`ai_status`),
  INDEX (`department`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: complaint_updates
CREATE TABLE IF NOT EXISTS `complaint_updates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `complaint_id` INT NOT NULL,
  `updated_by` VARCHAR(100) NOT NULL,
  `role` ENUM('Admin', 'Student') NOT NULL,
  `status` VARCHAR(50) NOT NULL,
  `remarks` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`complaint_id`) REFERENCES `complaints`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed default Admin (Password: admin123)
INSERT INTO `admins` (`username`, `password`, `full_name`, `email`, `role`)
VALUES ('admin', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'System Administrator', 'admin@college.edu', 'Super Admin')
ON DUPLICATE KEY UPDATE `password`=VALUES(`password`), `email`=VALUES(`email`);
