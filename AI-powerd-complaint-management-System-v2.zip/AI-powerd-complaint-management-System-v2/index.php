<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI-Powered College Complaint Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php"><i class="fa-solid fa-graduation-cap me-2"></i>CampusResolve AI</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navContent">
            <div class="ms-auto d-flex flex-wrap gap-2 mt-2 mt-lg-0">
                <a href="login.php" class="btn btn-outline-light"><i class="fa-solid fa-user me-1"></i> Student Login</a>
                <a href="register.php" class="btn btn-light"><i class="fa-solid fa-user-plus me-1"></i> Student Register</a>
                <a href="admin/login.php" class="btn btn-dark"><i class="fa-solid fa-lock me-1"></i> Admin Login</a>
                <a href="admin/register.php" class="btn btn-warning text-dark fw-semibold"><i class="fa-solid fa-user-shield me-1"></i> Admin Register</a>
            </div>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="row align-items-center mb-5">
        <div class="col-lg-6">
            <span class="badge bg-primary-subtle text-primary mb-2 px-3 py-2 rounded-pill fw-semibold">Next-Gen Campus Grievance System</span>
            <h1 class="display-5 fw-bold text-dark mb-3">AI-Driven College Complaint Resolution</h1>
            <p class="lead text-secondary mb-4">Submit, monitor, and resolve campus issues swiftly. Integrated with Python NLP for automatic classification, sentiment analysis, priority prediction, and Java JDBC batch reporting.</p>
            <div class="d-flex flex-wrap gap-2 mb-3">
                <a href="register.php" class="btn btn-primary btn-lg px-4"><i class="fa-solid fa-pen-to-square me-2"></i>Lodge a Complaint</a>
                <a href="login.php" class="btn btn-outline-secondary btn-lg px-4">Track Status</a>
                <a href="admin/register.php" class="btn btn-outline-dark btn-lg px-4"><i class="fa-solid fa-id-badge me-2"></i>Admin Register</a>
            </div>
        </div>
        <div class="col-lg-6 text-center mt-4 mt-lg-0">
            <div class="card shadow-lg border-0 p-4 rounded-4 bg-white">
                <div class="row g-3">
                    <div class="col-6">
                        <div class="p-3 bg-light rounded-3 text-center border">
                            <i class="fa-solid fa-brain text-primary fs-2 mb-2"></i>
                            <h5 class="fw-bold">AI Categorizer</h5>
                            <small class="text-muted">Auto-detects department & urgency</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3 bg-light rounded-3 text-center border">
                            <i class="fa-solid fa-bolt text-warning fs-2 mb-2"></i>
                            <h5 class="fw-bold">Priority Triage</h5>
                            <small class="text-muted">High, Medium & Low routing</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3 bg-light rounded-3 text-center border">
                            <i class="fa-solid fa-chart-pie text-success fs-2 mb-2"></i>
                            <h5 class="fw-bold">Java Reporting</h5>
                            <small class="text-muted">Automated CSV metric pipeline</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3 bg-light rounded-3 text-center border">
                            <i class="fa-solid fa-arrows-rotate text-info fs-2 mb-2"></i>
                            <h5 class="fw-bold">30s Live Sync</h5>
                            <small class="text-muted">Real-time status updates</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer class="text-center py-4 text-muted border-top bg-white">
    <p class="mb-0">&copy; 2026 AI-Powered College Complaint Management System. All rights reserved.</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
