<?php
require_once '../config/db.php';

try {
    // Generate secure password hash for 'admin123'
    $password = 'admin123';
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Inspect existing column names in the 'admins' table
    $colStmt = $pdo->query("SHOW COLUMNS FROM admins");
    $columns = $colStmt->fetchAll(PDO::FETCH_COLUMN);

    if (in_array('username', $columns)) {
        // Remove existing duplicate admin record if present
        $stmt = $pdo->prepare("DELETE FROM admins WHERE username = 'admin' OR email = 'admin@college.edu'");
        $stmt->execute();

        // Insert fresh admin record with username column
        $insert = $pdo->prepare("INSERT INTO admins (username, password, full_name, email, role) VALUES ('admin', ?, 'System Administrator', 'admin@college.edu', 'Super Admin')");
        $insert->execute([$hashedPassword]);
    } else {
        // Fallback insertion if table uses email as primary identifier
        $stmt = $pdo->prepare("DELETE FROM admins WHERE email = 'admin@college.edu'");
        $stmt->execute();

        $insert = $pdo->prepare("INSERT INTO admins (email, password, full_name, role) VALUES ('admin@college.edu', ?, 'System Administrator', 'Super Admin')");
        $insert->execute([$hashedPassword]);
    }

    echo "<h2 style='color: green;'>Admin Account Successfully Created / Reset!</h2>";
    echo "<p><strong>Username / Email:</strong> admin (or admin@college.edu)</p>";
    echo "<p><strong>Password:</strong> admin123</p>";
    echo "<p><a href='login.php'>Click here to Login</a></p>";

} catch (PDOException $e) {
    echo "<h2 style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</h2>";
}
?>
