<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['admin_user'])) {
    header("Location: login.php");
    exit;
}

// 1. AI Monitoring Dashboard Metrics
$aiCompleted = $pdo->query("SELECT COUNT(*) FROM complaints WHERE ai_status = 'Completed'")->fetchColumn();
$aiPending   = $pdo->query("SELECT COUNT(*) FROM complaints WHERE ai_status = 'Pending'")->fetchColumn();
$aiFailed    = $pdo->query("SELECT COUNT(*) FROM complaints WHERE ai_status = 'Failed'")->fetchColumn();

$aiTotal = $aiCompleted + $aiPending + $aiFailed;
$completionRate = ($aiTotal > 0) ? round(($aiCompleted / $aiTotal) * 100, 1) : 0;

// 2. Read Java Analysis CSV Output (reports/java_analysis.csv)
$csvPath = __DIR__ . '/../reports/java_analysis.csv';
$javaMetrics = [
    'total_complaints' => 0,
    'open_complaints' => 0,
    'escalation_alerts' => 0,
    'department_workload' => []
];

if (file_exists($csvPath)) {
    if (($handle = fopen($csvPath, "r")) !== FALSE) {
        $section = '';
        while (($row = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if (empty($row[0])) continue;
            if ($row[0] === 'METRIC') {
                $section = 'metrics';
                continue;
            }
            if ($row[0] === 'DEPARTMENT') {
                $section = 'workload';
                continue;
            }

            if ($section === 'metrics') {
                if ($row[0] === 'Total Complaints') $javaMetrics['total_complaints'] = $row[1];
                elseif ($row[0] === 'Open Complaints') $javaMetrics['open_complaints'] = $row[1];
                elseif ($row[0] === 'Escalation Alerts') $javaMetrics['escalation_alerts'] = $row[1];
            } elseif ($section === 'workload') {
                $javaMetrics['department_workload'][$row[0]] = $row[1];
            }
        }
        fclose($handle);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Monitoring & Java Reports - CampusResolve</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="dashboard.php">CampusResolve Admin</a>
        <div class="d-flex align-items-center">
            <!-- 30-Second Refresh Indicator -->
            <div class="text-light me-3 d-flex align-items-center gap-2">
                <span class="badge bg-secondary p-2 d-flex align-items-center gap-2">
                    <i class="fa-solid fa-arrows-rotate fa-spin text-info" id="refreshIcon"></i>
                    Auto-refresh in <strong id="refreshTimer">30</strong>s
                </span>
                <button class="btn btn-sm btn-outline-light" id="pauseRefreshBtn" onclick="toggleAutoRefresh()"><i class="fa-solid fa-pause"></i></button>
            </div>
            <a href="dashboard.php" class="btn btn-outline-light btn-sm me-2"><i class="fa-solid fa-gauge me-1"></i> Dashboard</a>
            <a href="../logout.php" class="btn btn-danger btn-sm"><i class="fa-solid fa-power-off"></i></a>
        </div>
    </div>
</nav>

<div class="container-fluid px-4 py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-0">System Analytics & Monitoring Hub</h4>
            <small class="text-muted">Real-time telemetry from Python NLP Engine & Java Workload Analyzer</small>
        </div>
        <div>
            <a href="../ai/retry_pending_complaints.php" target="_blank" class="btn btn-outline-primary btn-sm me-2">
                <i class="fa-solid fa-robot me-1"></i> Trigger AI Retry Now
            </a>
        </div>
    </div>

    <!-- Section 1: AI Engine Monitoring Dashboard -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white py-3">
            <h5 class="mb-0 fw-bold"><i class="fa-solid fa-brain text-primary me-2"></i>AI Processing Telemetry</h5>
        </div>
        <div class="card-body">
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="p-3 bg-light rounded border text-center">
                        <small class="text-muted">AI Completed</small>
                        <h3 class="fw-bold text-success mb-0"><?= $aiCompleted ?></h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="p-3 bg-light rounded border text-center">
                        <small class="text-muted">AI Pending / Retrying</small>
                        <h3 class="fw-bold text-warning mb-0"><?= $aiPending ?></h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="p-3 bg-light rounded border text-center">
                        <small class="text-muted">AI Failed</small>
                        <h3 class="fw-bold text-danger mb-0"><?= $aiFailed ?></h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="p-3 bg-light rounded border text-center">
                        <small class="text-muted">Analysis Success Rate</small>
                        <h3 class="fw-bold text-primary mb-0"><?= $completionRate ?>%</h3>
                    </div>
                </div>
            </div>

            <div class="mb-2 d-flex justify-content-between">
                <small class="fw-bold">Overall AI Completion Progress</small>
                <small class="fw-bold"><?= $completionRate ?>%</small>
            </div>
            <div class="progress" style="height: 14px;">
                <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" role="progressbar" style="width: <?= $completionRate ?>%"></div>
            </div>
        </div>
    </div>

    <!-- Section 2: Java Complaint Analyzer (JDBC Export) -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold"><i class="fa-brands fa-java text-danger me-2"></i>Java JDBC Analysis Workload Report</h5>
            <small class="text-muted">Source: reports/java_analysis.csv</small>
        </div>
        <div class="card-body">
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="p-3 border rounded text-center">
                        <small class="text-muted">JDBC Total Complaints</small>
                        <h4 class="fw-bold mb-0"><?= $javaMetrics['total_complaints'] ?></h4>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-3 border rounded text-center">
                        <small class="text-muted">JDBC Open Workload</small>
                        <h4 class="fw-bold text-warning mb-0"><?= $javaMetrics['open_complaints'] ?></h4>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-3 border rounded text-center">
                        <small class="text-muted">Escalation Threshold Alerts</small>
                        <h4 class="fw-bold text-danger mb-0"><?= $javaMetrics['escalation_alerts'] ?></h4>
                    </div>
                </div>
            </div>

            <h6 class="fw-bold mb-3">Department-wise Open Workload Distribution</h6>
            <div class="table-responsive">
                <table class="table table-bordered table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Department Name</th>
                            <th>Active Unresolved Complaints</th>
                            <th>Action Urgency</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($javaMetrics['department_workload'])): ?>
                        <tr><td colspan="3" class="text-center py-3 text-muted">No CSV data found. Run the Java analyzer batch file to generate metrics.</td></tr>
                    <?php else: ?>
                        <?php foreach ($javaMetrics['department_workload'] as $dept => $count): ?>
                            <tr>
                                <td class="fw-semibold"><?= htmlspecialchars($dept) ?></td>
                                <td><?= htmlspecialchars($count) ?></td>
                                <td>
                                    <?php if ($count >= 5): ?>
                                        <span class="badge bg-danger">Critical Workload</span>
                                    <?php elseif ($count >= 2): ?>
                                        <span class="badge bg-warning text-dark">Moderate</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Normal</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// 30-Second Refresh Countdown
let timeLeft = 30;
let isPaused = false;
const timerEl = document.getElementById('refreshTimer');
const btnEl = document.getElementById('pauseRefreshBtn');
const iconEl = document.getElementById('refreshIcon');

setInterval(() => {
    if (!isPaused) {
        timeLeft--;
        timerEl.innerText = timeLeft;
        if (timeLeft <= 0) {
            window.location.reload();
        }
    }
}, 1000);

function toggleAutoRefresh() {
    isPaused = !isPaused;
    if (isPaused) {
        btnEl.innerHTML = '<i class="fa-solid fa-play"></i>';
        iconEl.classList.remove('fa-spin');
    } else {
        btnEl.innerHTML = '<i class="fa-solid fa-pause"></i>';
        iconEl.classList.add('fa-spin');
    }
}
</script>
</body>
</html>
