<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['admin_user'])) {
    header("Location: login.php");
    exit;
}

// Fetch overview metrics
$totalComplaints = $pdo->query("SELECT COUNT(*) FROM complaints")->fetchColumn();
$openComplaints = $pdo->query("SELECT COUNT(*) FROM complaints WHERE status IN ('Submitted', 'In Progress')")->fetchColumn();
$resolvedComplaints = $pdo->query("SELECT COUNT(*) FROM complaints WHERE status = 'Resolved'")->fetchColumn();
$highPriority = $pdo->query("SELECT COUNT(*) FROM complaints WHERE priority = 'High' AND status != 'Resolved'")->fetchColumn();

// Fetch latest complaints
$stmt = $pdo->query("SELECT c.*, u.full_name as student_name FROM complaints c LEFT JOIN users u ON c.student_id = u.student_id ORDER BY c.created_date DESC LIMIT 15");
$recentComplaints = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - CampusResolve AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="dashboard.php"><i class="fa-solid fa-shield-halved me-2"></i>CampusResolve Admin</a>
        <div class="d-flex align-items-center">
            <!-- 30-Second Refresh Indicator -->
            <div class="text-light me-3 d-flex align-items-center gap-2">
                <span class="badge bg-secondary p-2 d-flex align-items-center gap-2">
                    <i class="fa-solid fa-arrows-rotate fa-spin text-info" id="refreshIcon"></i>
                    Auto-refresh in <strong id="refreshTimer">30</strong>s
                </span>
                <button class="btn btn-sm btn-outline-light" id="pauseRefreshBtn" onclick="toggleAutoRefresh()"><i class="fa-solid fa-pause"></i></button>
            </div>
            <a href="reports.php" class="btn btn-outline-info btn-sm me-2"><i class="fa-solid fa-chart-line me-1"></i> AI & Java Reports</a>
            <a href="users.php" class="btn btn-outline-secondary btn-sm me-2"><i class="fa-solid fa-users me-1"></i> Students</a>
            <a href="../logout.php" class="btn btn-danger btn-sm"><i class="fa-solid fa-power-off"></i></a>
        </div>
    </div>
</nav>

<div class="container-fluid px-4 py-4">
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white border-start border-primary border-4">
                <div class="text-muted small">Total Complaints</div>
                <h2 class="fw-bold mb-0 text-primary"><?= $totalComplaints ?></h2>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white border-start border-warning border-4">
                <div class="text-muted small">Active Open Cases</div>
                <h2 class="fw-bold mb-0 text-warning"><?= $openComplaints ?></h2>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white border-start border-danger border-4">
                <div class="text-muted small">High Priority Escalations</div>
                <h2 class="fw-bold mb-0 text-danger"><?= $highPriority ?></h2>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white border-start border-success border-4">
                <div class="text-muted small">Resolved Complaints</div>
                <h2 class="fw-bold mb-0 text-success"><?= $resolvedComplaints ?></h2>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold"><i class="fa-solid fa-list-check me-2 text-primary"></i>Live Complaint Feed</h5>
            <small class="text-muted">Updated automatically every 30 seconds</small>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#ID</th>
                            <th>Student</th>
                            <th>Title & Summary</th>
                            <th>AI Department</th>
                            <th>AI Priority</th>
                            <th>Sentiment</th>
                            <th>Status</th>
                            <th>AI Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($recentComplaints)): ?>
                        <tr><td colspan="10" class="text-center py-4 text-muted">No grievances submitted.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recentComplaints as $c): ?>
                            <tr>
                                <td><strong>#<?= $c['id'] ?></strong></td>
                                <td>
                                    <div><?= htmlspecialchars($c['student_name'] ?? 'N/A') ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($c['student_id']) ?></small>
                                </td>
                                <td style="max-width: 280px;">
                                    <div class="fw-bold text-truncate"><?= htmlspecialchars($c['title']) ?></div>
                                    <small class="text-muted text-truncate d-block"><?= htmlspecialchars($c['ai_summary'] ?? substr($c['description'], 0, 70)) ?></small>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($c['department'] ?? 'Unassigned') ?></span></td>
                                <td>
                                    <?php
                                    $p_badge = 'bg-secondary';
                                    if ($c['priority'] === 'High') $p_badge = 'bg-danger';
                                    elseif ($c['priority'] === 'Medium') $p_badge = 'bg-warning text-dark';
                                    elseif ($c['priority'] === 'Low') $p_badge = 'bg-info text-dark';
                                    ?>
                                    <span class="badge <?= $p_badge ?>"><?= htmlspecialchars($c['priority']) ?></span>
                                </td>
                                <td>
                                    <?php
                                    $s_badge = 'bg-secondary';
                                    if ($c['sentiment'] === 'Negative') $s_badge = 'bg-danger-subtle text-danger';
                                    elseif ($c['sentiment'] === 'Positive') $s_badge = 'bg-success-subtle text-success';
                                    else $s_badge = 'bg-light text-dark';
                                    ?>
                                    <span class="badge <?= $s_badge ?>"><?= htmlspecialchars($c['sentiment']) ?></span>
                                </td>
                                <td>
                                    <?php
                                    $st_badge = 'bg-secondary';
                                    if ($c['status'] === 'Resolved') $st_badge = 'bg-success';
                                    elseif ($c['status'] === 'In Progress') $st_badge = 'bg-warning text-dark';
                                    elseif ($c['status'] === 'Submitted') $st_badge = 'bg-primary';
                                    ?>
                                    <span class="badge <?= $st_badge ?>"><?= htmlspecialchars($c['status']) ?></span>
                                </td>
                                <td>
                                    <?php if ($c['ai_status'] === 'Completed'): ?>
                                        <span class="badge bg-success-subtle text-success"><i class="fa-solid fa-check"></i> Done</span>
                                    <?php elseif ($c['ai_status'] === 'Pending'): ?>
                                        <span class="badge bg-warning-subtle text-warning"><i class="fa-solid fa-clock"></i> Pending</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger"><i class="fa-solid fa-xmark"></i> Failed</span>
                                    <?php endif; ?>
                                </td>
                                <td><small class="text-muted"><?= date('M d, H:i', strtotime($c['created_date'])) ?></small></td>
                                <td>
                                    <a href="manage_complaint.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-gear"></i> Manage</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// 30-Second Automatic Browser Refresh Logic
let timeLeft = 30;
let isPaused = false;
const timerEl = document.getElementById('refreshTimer');
const btnEl = document.getElementById('pauseRefreshBtn');
const iconEl = document.getElementById('refreshIcon');

const countdown = setInterval(() => {
    if (!isPaused) {
        timeLeft--;
        timerEl.innerText = timeLeft;
        if (timeLeft <= 0) {
            window.location.reload();
        }
    }
}, 1000);

function toggleAutoRefresh() {
    isPaused = !isPaused;
    if (isPaused) {
        btnEl.innerHTML = '<i class="fa-solid fa-play"></i>';
        iconEl.classList.remove('fa-spin');
    } else {
        btnEl.innerHTML = '<i class="fa-solid fa-pause"></i>';
        iconEl.classList.add('fa-spin');
    }
}
</script>
</body>
</html>
