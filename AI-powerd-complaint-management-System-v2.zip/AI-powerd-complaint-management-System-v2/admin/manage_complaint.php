<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['admin_user'])) {
    header("Location: login.php");
    exit;
}

$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT c.*, u.full_name as student_name, u.email as student_email, u.phone as student_phone FROM complaints c LEFT JOIN users u ON c.student_id = u.student_id WHERE c.id = ?");
$stmt->execute([$id]);
$complaint = $stmt->fetch();

if (!$complaint) {
    die("Complaint not found.");
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newStatus     = $_POST['status'] ?? $complaint['status'];
    $newPriority   = $_POST['priority'] ?? $complaint['priority'];
    $newDepartment = $_POST['department'] ?? $complaint['department'];
    $remarks       = trim($_POST['remarks'] ?? '');

    $resolvedDate = ($newStatus === 'Resolved') ? date('Y-m-d H:i:s') : null;

    $upd = $pdo->prepare("UPDATE complaints SET status = ?, priority = ?, department = ?, resolved_date = ? WHERE id = ?");
    $upd->execute([$newStatus, $newPriority, $newDepartment, $resolvedDate, $id]);

    if (!empty($remarks)) {
        $track = $pdo->prepare("INSERT INTO complaint_updates (complaint_id, updated_by, role, status, remarks) VALUES (?, ?, 'Admin', ?, ?)");
        $track->execute([$id, $_SESSION['admin_user'], $newStatus, $remarks]);
    }

    $msg = "Complaint updated successfully!";
    $stmt->execute([$id]);
    $complaint = $stmt->fetch();
}

$trailStmt = $pdo->prepare("SELECT * FROM complaint_updates WHERE complaint_id = ? ORDER BY created_at DESC");
$trailStmt->execute([$id]);
$trail = $trailStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Complaint #<?= $complaint['id'] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="dashboard.php">CampusResolve Admin</a>
        <div class="ms-auto">
            <a href="dashboard.php" class="btn btn-outline-light btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> Back to Dashboard</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <?php if ($msg): ?>
        <div class="alert alert-success"><?= $msg ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold">Complaint #<?= $complaint['id'] ?>: <?= htmlspecialchars($complaint['title']) ?></h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong>Student:</strong> <?= htmlspecialchars($complaint['student_name'] ?? 'N/A') ?> (<?= htmlspecialchars($complaint['student_id']) ?>)<br>
                        <strong>Email:</strong> <?= htmlspecialchars($complaint['student_email'] ?? 'N/A') ?> | <strong>Phone:</strong> <?= htmlspecialchars($complaint['student_phone'] ?? 'N/A') ?>
                    </div>
                    <hr>
                    <h6>Description</h6>
                    <p class="bg-light p-3 rounded"><?= nl2br(htmlspecialchars($complaint['description'])) ?></p>

                    <?php if ($complaint['attachment']): ?>
                        <h6>Attachment</h6>
                        <a href="../uploads/<?= htmlspecialchars($complaint['attachment']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                            <i class="fa-solid fa-download me-1"></i> View Attached File
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h6 class="mb-0 fw-bold">Update History</h6>
                </div>
                <div class="card-body">
                    <?php if (empty($trail)): ?>
                        <p class="text-muted small">No remarks yet.</p>
                    <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($trail as $t): ?>
                                <li class="list-group-item px-0">
                                    <div class="d-flex justify-content-between">
                                        <strong><?= htmlspecialchars($t['updated_by']) ?> (<?= htmlspecialchars($t['role']) ?>)</strong>
                                        <small class="text-muted"><?= $t['created_at'] ?></small>
                                    </div>
                                    <span class="badge bg-secondary"><?= htmlspecialchars($t['status']) ?></span>
                                    <p class="mt-1 mb-0 text-dark"><?= nl2br(htmlspecialchars($t['remarks'])) ?></p>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-primary text-white py-3">
                    <h6 class="mb-0 fw-bold"><i class="fa-solid fa-pen-to-square me-2"></i>Update Status & Department</h6>
                </div>
                <div class="card-body">
                    <form action="manage_complaint.php?id=<?= $id ?>" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Status</label>
                            <select name="status" class="form-select">
                                <option value="Submitted" <?= $complaint['status'] === 'Submitted' ? 'selected' : '' ?>>Submitted</option>
                                <option value="In Progress" <?= $complaint['status'] === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                                <option value="Resolved" <?= $complaint['status'] === 'Resolved' ? 'selected' : '' ?>>Resolved</option>
                                <option value="Rejected" <?= $complaint['status'] === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Priority</label>
                            <select name="priority" class="form-select">
                                <option value="Low" <?= $complaint['priority'] === 'Low' ? 'selected' : '' ?>>Low</option>
                                <option value="Medium" <?= $complaint['priority'] === 'Medium' ? 'selected' : '' ?>>Medium</option>
                                <option value="High" <?= $complaint['priority'] === 'High' ? 'selected' : '' ?>>High</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Assigned Department</label>
                            <input type="text" name="department" class="form-control" value="<?= htmlspecialchars($complaint['department'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Action Note / Resolution Remarks</label>
                            <textarea name="remarks" rows="3" class="form-control" placeholder="Explain the resolution or status change..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100"><i class="fa-solid fa-floppy-disk me-1"></i> Save Changes</button>
                    </form>
                </div>
            </div>

            <div class="card border-0 shadow-sm bg-white">
                <div class="card-header bg-dark text-white py-3">
                    <h6 class="mb-0 fw-bold"><i class="fa-solid fa-robot text-warning me-2"></i>AI Automated Analysis</h6>
                </div>
                <div class="card-body">
                    <p><strong>Predicted Category:</strong> <?= htmlspecialchars($complaint['ai_predicted_category'] ?? 'N/A') ?></p>
                    <p><strong>Sentiment:</strong> <?= htmlspecialchars($complaint['sentiment'] ?? 'N/A') ?></p>
                    <p><strong>AI Status:</strong> <span class="badge bg-secondary"><?= htmlspecialchars($complaint['ai_status']) ?></span></p>
                    <p class="mb-1"><strong>AI Summary:</strong></p>
                    <div class="small bg-light p-2 rounded"><?= htmlspecialchars($complaint['ai_summary'] ?? 'N/A') ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
