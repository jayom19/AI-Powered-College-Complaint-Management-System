<?php
session_start();
// Enable full PHP error reporting for diagnostics
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username  = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $role      = trim($_POST['role'] ?? 'Admin');
    $password  = $_POST['password'] ?? '';

    if (empty($username) || empty($full_name) || empty($email) || empty($password)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            // 1. Ensure table exists with correct schema
            $pdo->exec("CREATE TABLE IF NOT EXISTS `admins` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `username` VARCHAR(50) NOT NULL UNIQUE,
                `password` VARCHAR(255) NOT NULL,
                `full_name` VARCHAR(100) NOT NULL,
                `email` VARCHAR(100) NOT NULL UNIQUE,
                `role` VARCHAR(50) DEFAULT 'Admin',
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

            // 2. Check if username already exists
            $chkUser = $pdo->prepare("SELECT id FROM admins WHERE username = ?");
            $chkUser->execute([$username]);
            if ($chkUser->fetch()) {
                $error = "Username '<strong>" . htmlspecialchars($username) . "</strong>' already exists. Choose a different one.";
            }

            // 3. Check if email already exists
            if (empty($error)) {
                $chkEmail = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
                $chkEmail->execute([$email]);
                if ($chkEmail->fetch()) {
                    $error = "Email '<strong>" . htmlspecialchars($email) . "</strong>' already exists. Choose a different email.";
                }
            }

            // 4. Perform direct Insert
            if (empty($error)) {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO admins (username, password, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
                $success = $stmt->execute([$username, $hashed, $full_name, $email, $role]);

                if ($success) {
                    $message = "Admin registered successfully into database! <a href='login.php' class='alert-link fw-bold'>Login Now</a>";
                } else {
                    $error = "Insert query execution returned false.";
                }
            }
        } catch (PDOException $e) {
            $error = "SQL / Database Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Registration - CampusResolve AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-light d-flex align-items-center justify-content-center py-5" style="min-height: 100vh;">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card bg-secondary text-white border-0 shadow-lg">
                <div class="card-header bg-primary text-center py-3">
                    <h4 class="mb-0 fw-bold"><i class="fa-solid fa-user-shield me-2"></i>Admin Registration</h4>
                </div>
                <div class="card-body p-4">
                    <?php if ($message): ?>
                        <div class="alert alert-success"><?= $message ?></div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <form action="register.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Username *</label>
                            <input type="text" name="username" class="form-control" required placeholder="e.g., sub_admin">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="full_name" class="form-control" required placeholder="Enter full name">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email Address *</label>
                            <input type="email" name="email" class="form-control" required placeholder="e.g. myadmin@college.edu">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-select">
                                <option value="Admin">Department Admin</option>
                                <option value="Grievance Officer">Grievance Officer</option>
                                <option value="Super Admin">Super Admin</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password *</label>
                            <input type="password" name="password" class="form-control" required placeholder="Enter password">
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Register Admin</button>
                    </form>
                    <div class="text-center mt-3">
                        <small>Already registered? <a href="login.php" class="text-light">Login here</a> | <a href="../index.php" class="text-light">Home</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>