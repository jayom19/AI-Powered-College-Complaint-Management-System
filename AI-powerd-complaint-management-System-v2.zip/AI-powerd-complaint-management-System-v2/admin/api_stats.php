<?php
header('Content-Type: application/json');
require_once '../config/db.php';

try {
    $totalComplaints = $pdo->query("SELECT COUNT(*) FROM complaints")->fetchColumn();
    $openComplaints = $pdo->query("SELECT COUNT(*) FROM complaints WHERE status IN ('Submitted', 'In Progress')")->fetchColumn();
    $resolvedComplaints = $pdo->query("SELECT COUNT(*) FROM complaints WHERE status = 'Resolved'")->fetchColumn();
    $highPriority = $pdo->query("SELECT COUNT(*) FROM complaints WHERE priority = 'High' AND status != 'Resolved'")->fetchColumn();

    $aiCompleted = $pdo->query("SELECT COUNT(*) FROM complaints WHERE ai_status = 'Completed'")->fetchColumn();
    $aiPending   = $pdo->query("SELECT COUNT(*) FROM complaints WHERE ai_status = 'Pending'")->fetchColumn();
    $aiFailed    = $pdo->query("SELECT COUNT(*) FROM complaints WHERE ai_status = 'Failed'")->fetchColumn();

    echo json_encode([
        'status' => 'success',
        'timestamp' => date('Y-m-d H:i:s'),
        'metrics' => [
            'total' => (int)$totalComplaints,
            'open' => (int)$openComplaints,
            'resolved' => (int)$resolvedComplaints,
            'high_priority' => (int)$highPriority,
            'ai_completed' => (int)$aiCompleted,
            'ai_pending' => (int)$aiPending,
            'ai_failed' => (int)$aiFailed
        ]
    ]);
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
