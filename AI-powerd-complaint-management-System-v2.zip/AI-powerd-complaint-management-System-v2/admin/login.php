<?php
session_start();
require_once '../config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputUser = trim($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';

    if (empty($inputUser) || empty($password)) {
        $error = "Please enter both username/email and password.";
    } else {
        try {
            // Inspect existing column names in the 'admins' table
            $colStmt = $pdo->query("SHOW COLUMNS FROM admins");
            $columns = $colStmt->fetchAll(PDO::FETCH_COLUMN);

            $admin = null;

            // Check if 'username' column exists
            if (in_array('username', $columns)) {
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? OR email = ? LIMIT 1");
                $stmt->execute([$inputUser, $inputUser]);
                $admin = $stmt->fetch();
            } elseif (in_array('email', $columns)) {
                // Fallback if table only contains 'email'
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ? LIMIT 1");
                $stmt->execute([$inputUser]);
                $admin = $stmt->fetch();
            } elseif (in_array('admin_id', $columns)) {
                // Fallback if table uses 'admin_id'
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE admin_id = ? LIMIT 1");
                $stmt->execute([$inputUser]);
                $admin = $stmt->fetch();
            }

            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'] ?? 1;
                $_SESSION['admin_user'] = $admin['username'] ?? ($admin['email'] ?? 'admin');
                $_SESSION['admin_role'] = $admin['role'] ?? 'Admin';
                header("Location: dashboard.php");
                exit;
            } else {
                $error = "Invalid administrator credentials. If you have not created an admin yet, please use Admin Register.";
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Portal Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-light d-flex align-items-center justify-content-center" style="min-height: 100vh;">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card bg-secondary text-white border-0 shadow-lg">
                <div class="card-header bg-primary text-center py-3">
                    <h4 class="mb-0 fw-bold"><i class="fa-solid fa-lock me-2"></i>Admin Portal</h4>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    <form action="login.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Username / Email</label>
                            <input type="text" name="username" class="form-control" required placeholder="admin">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required placeholder="admin123">
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Login to Admin Console</button>
                    </form>
                    <div class="text-center mt-3">
                        <small>Need an account? <a href="register.php" class="text-warning text-decoration-none fw-bold">Register Admin</a> | <a href="../index.php" class="text-light text-decoration-none">&larr; Home</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
