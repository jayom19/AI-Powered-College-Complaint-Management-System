<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit;
}

$student_id = $_SESSION['student_id'];
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title       = trim($_POST['title'] ?? '');
    $category    = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');

    // File upload handling
    $attachment = null;
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['jpg', 'jpeg', 'png', 'pdf', 'docx'];
        $ext = strtolower(pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $newName = uniqid('att_', true) . '.' . $ext;
            $dest = '../uploads/' . $newName;
            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $dest)) {
                $attachment = $newName;
            }
        }
    }

    if (empty($title) || empty($description)) {
        $error = "Please provide both title and description.";
    } else {
        // Insert initial complaint with ai_status = 'Pending'
        $stmt = $pdo->prepare("INSERT INTO complaints (student_id, title, description, category, attachment, status, ai_status) VALUES (?, ?, ?, ?, ?, 'Submitted', 'Pending')");
        $stmt->execute([$student_id, $title, $description, $category, $attachment]);
        $complaint_id = $pdo->lastInsertId();

        // Trigger Python AI Analysis
        $pyScript = realpath(__DIR__ . '/../ai/analyze_complaint.py');
        $pythonExec = 'python';
        
        $escapedTitle = escapeshellarg($title);
        $escapedDesc  = escapeshellarg($description);
        $escapedCat   = escapeshellarg($category);

        // Fixed command string (No quote escaping conflict)
        $command = $pythonExec . ' ' . escapeshellarg($pyScript) . ' ' . $escapedTitle . ' ' . $escapedDesc . ' ' . $escapedCat . ' 2>&1';
        $aiOutput = shell_exec($command);
        $aiData = json_decode($aiOutput, true);

        if ($aiData && isset($aiData['status']) && $aiData['status'] === 'success') {
            $upd = $pdo->prepare("UPDATE complaints SET 
                ai_predicted_category = ?, 
                department = ?, 
                priority = ?, 
                sentiment = ?, 
                ai_summary = ?, 
                ai_status = 'Completed' 
                WHERE id = ?");
            $upd->execute([
                $aiData['predicted_category'] ?? $category,
                $aiData['department'] ?? 'General',
                $aiData['priority'] ?? 'Medium',
                $aiData['sentiment'] ?? 'Neutral',
                $aiData['summary'] ?? substr($description, 0, 100),
                $complaint_id
            ]);
        } else {
            $pdo->prepare("UPDATE complaints SET ai_status = 'Pending' WHERE id = ?")->execute([$complaint_id]);
        }

        // Add initial tracking entry
        $track = $pdo->prepare("INSERT INTO complaint_updates (complaint_id, updated_by, role, status, remarks) VALUES (?, ?, 'Student', 'Submitted', 'Grievance submitted by student.')");
        $track->execute([$complaint_id, $_SESSION['user_name'] ?? 'Student']);

        header("Location: view_complaint.php?id=" . $complaint_id . "&submitted=1");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Complaint</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php">CampusResolve AI</a>
        <div class="ms-auto text-white">
            <a href="dashboard.php" class="btn btn-outline-light btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> Back to Dashboard</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3 border-bottom">
                    <h5 class="mb-0 fw-bold"><i class="fa-solid fa-file-circle-plus text-primary me-2"></i>Lodge a New Complaint</h5>
                    <small class="text-muted">AI engine will automatically analyze urgency, sentiment, and direct to the right department.</small>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>

                    <form action="submit_complaint.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Complaint Subject / Title *</label>
                            <input type="text" name="title" class="form-control" placeholder="e.g. Broken projector in Lab 4, Network outage in Hostel B" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Primary Category *</label>
                            <select name="category" class="form-select" required>
                                <option value="Academic">Academic (Lectures, Grading, Exams)</option>
                                <option value="Hostel & Mess">Hostel & Mess (Food, Hygiene, Room issues)</option>
                                <option value="Infrastructure">Infrastructure (Labs, AC, Water, Lighting)</option>
                                <option value="IT & Network">IT & Network (Wi-Fi, Portal, Library Computers)</option>
                                <option value="Administration">Administration & Fees</option>
                                <option value="Discipline & Security">Discipline, Ragging & Security</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Detailed Description *</label>
                            <textarea name="description" rows="5" class="form-control" placeholder="Describe the incident or grievance clearly. Mention room numbers, dates, and severity..." required></textarea>
                            <div class="form-text">Our Natural Language Processing model uses this text to gauge priority.</div>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Supporting File or Screenshot (Optional)</label>
                            <input type="file" name="attachment" class="form-control" accept=".jpg,.jpeg,.png,.pdf,.docx">
                        </div>
                        <div class="d-flex justify-content-between">
                            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary px-4"><i class="fa-solid fa-paper-plane me-2"></i>Submit & Run AI Analysis</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>