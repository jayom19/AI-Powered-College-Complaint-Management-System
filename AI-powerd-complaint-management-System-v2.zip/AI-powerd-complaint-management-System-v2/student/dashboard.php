<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit;
}

$student_id = $_SESSION['student_id'];

// Get user complaints
$stmt = $pdo->prepare("SELECT * FROM complaints WHERE student_id = ? ORDER BY created_date DESC");
$stmt->execute([$student_id]);
$complaints = $stmt->fetchAll();

// Statistics
$total = count($complaints);
$resolved = 0;
$in_progress = 0;
$submitted = 0;

foreach ($complaints as $c) {
    if ($c['status'] === 'Resolved') $resolved++;
    elseif ($c['status'] === 'In Progress') $in_progress++;
    else $submitted++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php">CampusResolve AI</a>
        <div class="ms-auto text-white">
            <span class="me-3"><i class="fa-regular fa-user me-1"></i> <?= htmlspecialchars($_SESSION['user_name']) ?> (<?= htmlspecialchars($student_id) ?>)</span>
            <a href="submit_complaint.php" class="btn btn-warning btn-sm fw-bold me-2"><i class="fa-solid fa-plus me-1"></i> New Complaint</a>
            <a href="../logout.php" class="btn btn-outline-light btn-sm"><i class="fa-solid fa-power-off"></i></a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white border-start border-primary border-4">
                <div class="text-muted small">Total Filed</div>
                <h3 class="fw-bold mb-0"><?= $total ?></h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white border-start border-info border-4">
                <div class="text-muted small">Submitted / Pending</div>
                <h3 class="fw-bold mb-0"><?= $submitted ?></h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white border-start border-warning border-4">
                <div class="text-muted small">In Progress</div>
                <h3 class="fw-bold mb-0"><?= $in_progress ?></h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 bg-white border-start border-success border-4">
                <div class="text-muted small">Resolved</div>
                <h3 class="fw-bold mb-0"><?= $resolved ?></h3>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold">My Submitted Complaints</h5>
            <a href="submit_complaint.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus me-1"></i> Lodge Grievance</a>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Selected Category</th>
                            <th>AI Predicted Dept</th>
                            <th>AI Priority</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($complaints)): ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No complaints filed yet. Click "New Complaint" to submit one.</td></tr>
                    <?php else: ?>
                        <?php foreach ($complaints as $c): ?>
                            <tr>
                                <td>#<?= $c['id'] ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($c['title']) ?></td>
                                <td><span class="badge bg-secondary"><?= htmlspecialchars($c['category']) ?></span></td>
                                <td><?= htmlspecialchars($c['department'] ?? 'Pending AI') ?></td>
                                <td>
                                    <?php
                                    $p_badge = 'bg-secondary';
                                    if ($c['priority'] === 'High') $p_badge = 'bg-danger';
                                    elseif ($c['priority'] === 'Medium') $p_badge = 'bg-warning text-dark';
                                    elseif ($c['priority'] === 'Low') $p_badge = 'bg-info text-dark';
                                    ?>
                                    <span class="badge <?= $p_badge ?>"><?= htmlspecialchars($c['priority']) ?></span>
                                </td>
                                <td>
                                    <?php
                                    $s_badge = 'bg-secondary';
                                    if ($c['status'] === 'Resolved') $s_badge = 'bg-success';
                                    elseif ($c['status'] === 'In Progress') $s_badge = 'bg-warning text-dark';
                                    elseif ($c['status'] === 'Submitted') $s_badge = 'bg-info text-dark';
                                    elseif ($c['status'] === 'Rejected') $s_badge = 'bg-danger';
                                    ?>
                                    <span class="badge <?= $s_badge ?>"><?= htmlspecialchars($c['status']) ?></span>
                                </td>
                                <td><?= date('d M Y, h:i A', strtotime($c['created_date'])) ?></td>
                                <td>
                                    <a href="view_complaint.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-eye me-1"></i>View Details</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
