<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit;
}

$id = intval($_GET['id'] ?? 0);
$student_id = $_SESSION['student_id'];

$stmt = $pdo->prepare("SELECT * FROM complaints WHERE id = ? AND student_id = ?");
$stmt->execute([$id, $student_id]);
$complaint = $stmt->fetch();

if (!$complaint) {
    die("Complaint not found or unauthorized.");
}

$updStmt = $pdo->prepare("SELECT * FROM complaint_updates WHERE complaint_id = ? ORDER BY created_at ASC");
$updStmt->execute([$id]);
$updates = $updStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Complaint #<?= $complaint['id'] ?> Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php">CampusResolve AI</a>
        <div class="ms-auto text-white">
            <a href="dashboard.php" class="btn btn-outline-light btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> Dashboard</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <?php if (isset($_GET['submitted'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fa-solid fa-circle-check me-2"></i> Complaint registered successfully and routed to AI engine!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 fw-bold">Complaint #<?= $complaint['id'] ?>: <?= htmlspecialchars($complaint['title']) ?></h5>
                        <span class="badge bg-primary"><?= htmlspecialchars($complaint['status']) ?></span>
                    </div>
                </div>
                <div class="card-body">
                    <h6 class="fw-bold text-secondary">Description</h6>
                    <p class="text-dark bg-light p-3 rounded"><?= nl2br(htmlspecialchars($complaint['description'])) ?></p>

                    <?php if (!empty($complaint['attachment'])): ?>
                        <div class="mt-3">
                            <h6 class="fw-bold text-secondary">Attachment</h6>
                            <a href="../uploads/<?= htmlspecialchars($complaint['attachment']) ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
                                <i class="fa-solid fa-paperclip me-1"></i> View Attached Document
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold"><i class="fa-solid fa-timeline me-2 text-primary"></i>Resolution Trail</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($updates)): ?>
                        <p class="text-muted">No updates recorded yet.</p>
                    <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($updates as $u): ?>
                                <li class="list-group-item px-0">
                                    <div class="d-flex justify-content-between">
                                        <strong class="text-primary"><?= htmlspecialchars($u['updated_by']) ?> (<?= htmlspecialchars($u['role']) ?>)</strong>
                                        <small class="text-muted"><?= date('d M Y, h:i A', strtotime($u['created_at'])) ?></small>
                                    </div>
                                    <div class="badge bg-secondary mb-1"><?= htmlspecialchars($u['status']) ?></div>
                                    <p class="mb-0 text-dark"><?= nl2br(htmlspecialchars($u['remarks'])) ?></p>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3">
                    <h6 class="mb-0 fw-bold"><i class="fa-solid fa-robot text-warning me-2"></i>AI Assessment Card</h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <small class="text-muted d-block">AI Analysis Status</small>
                        <?php if ($complaint['ai_status'] === 'Completed'): ?>
                            <span class="badge bg-success"><i class="fa-solid fa-check me-1"></i> Completed</span>
                        <?php elseif ($complaint['ai_status'] === 'Pending'): ?>
                            <span class="badge bg-warning text-dark"><i class="fa-solid fa-clock me-1"></i> Queued for Retry</span>
                        <?php else: ?>
                            <span class="badge bg-danger"><i class="fa-solid fa-triangle-exclamation me-1"></i> Failed</span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <small class="text-muted d-block">Allocated Department</small>
                        <strong><?= htmlspecialchars($complaint['department'] ?? 'Analyzing...') ?></strong>
                    </div>
                    <div class="mb-3">
                        <small class="text-muted d-block">Predicted Priority</small>
                        <span class="badge bg-danger"><?= htmlspecialchars($complaint['priority'] ?? 'Medium') ?></span>
                    </div>
                    <div class="mb-3">
                        <small class="text-muted d-block">Detected Sentiment</small>
                        <span class="badge bg-secondary"><?= htmlspecialchars($complaint['sentiment'] ?? 'Neutral') ?></span>
                    </div>
                    <div class="mb-3">
                        <small class="text-muted d-block">AI Summary</small>
                        <p class="small text-muted mb-0 bg-light p-2 rounded"><?= htmlspecialchars($complaint['ai_summary'] ?? 'N/A') ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
