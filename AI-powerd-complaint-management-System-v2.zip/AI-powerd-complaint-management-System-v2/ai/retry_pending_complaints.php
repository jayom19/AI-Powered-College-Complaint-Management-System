<?php
// Automatic AI Retry System
// Scans complaints with Pending or Failed AI status and executes Python NLP analyzer
require_once __DIR__ . '/../config/db.php';

$isCli = (php_sapi_name() === 'cli');

if (!$isCli) {
    echo "<pre>";
}

echo "=== AI Complaint Retry Process Started: " . date('Y-m-d H:i:s') . " ===\n";

// Fetch up to 20 Pending or Failed complaints
$stmt = $pdo->prepare("SELECT id, title, description, category FROM complaints WHERE ai_status IN ('Pending', 'Failed') ORDER BY id ASC LIMIT 20");
$stmt->execute();
$complaints = $stmt->fetchAll();

$processed = count($complaints);
$completed = 0;
$failed = 0;

$pyScript = realpath(__DIR__ . '/analyze_complaint.py');
$pythonExec = 'python';

foreach ($complaints as $c) {
    $title = escapeshellarg($c['title']);
    $desc  = escapeshellarg($c['description']);
    $cat   = escapeshellarg($c['category']);

    $command = "{$pythonExec} "{$pyScript}" {$title} {$desc} {$cat} 2>&1";
    $output = shell_exec($command);
    $data = json_decode($output, true);

    if ($data && isset($data['status']) && $data['status'] === 'success') {
        $upd = $pdo->prepare("UPDATE complaints SET 
            ai_predicted_category = ?, 
            department = ?, 
            priority = ?, 
            sentiment = ?, 
            ai_summary = ?, 
            ai_status = 'Completed' 
            WHERE id = ?");
        $upd->execute([
            $data['predicted_category'],
            $data['department'],
            $data['priority'],
            $data['sentiment'],
            $data['summary'],
            $c['id']
        ]);
        $completed++;
        echo "[SUCCESS] Complaint #{$c['id']} successfully re-analyzed.\n";
    } else {
        $pdo->prepare("UPDATE complaints SET ai_status = 'Failed' WHERE id = ?")->execute([$c['id']]);
        $failed++;
        echo "[FAILED] Complaint #{$c['id']} analysis failed. Kept as Failed.\n";
    }
}

echo "\n=== Execution Summary ===\n";
echo "Total Processed: {$processed}\n";
echo "Successful: {$completed}\n";
echo "Failed: {$failed}\n";
echo "Finished at: " . date('Y-m-d H:i:s') . "\n";

if (!$isCli) {
    echo "</pre>";
    echo "<br><a href='../admin/reports.php'>Back to Admin Reports</a>";
}
?>
