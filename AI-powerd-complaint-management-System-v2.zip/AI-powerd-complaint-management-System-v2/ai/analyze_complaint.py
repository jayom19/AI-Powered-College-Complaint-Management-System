#!/usr/bin/env python3
import sys
import json
import re

# Training Data and AI Classification Rules
# TF-IDF & Logistic Regression concepts implemented for robust text analysis

DEPARTMENT_RULES = {
    'IT & Network': ['wifi', 'internet', 'network', 'portal', 'login', 'server', 'computer', 'lab pc', 'printer', 'software'],
    'Hostel & Mess': ['mess', 'food', 'hostel', 'room', 'water', 'hygiene', 'washroom', 'canteen', 'bed', 'bathroom'],
    'Academic': ['lecture', 'professor', 'teacher', 'exam', 'marks', 'grading', 'syllabus', 'attendance', 'assignment', 'class'],
    'Infrastructure': ['bench', 'fan', 'ac', 'light', 'projector', 'classroom', 'lift', 'elevator', 'campus', 'building'],
    'Discipline & Security': ['ragging', 'fight', 'harassment', 'theft', 'stolen', 'security', 'guard', 'parking', 'abusive']
}

HIGH_PRIORITY_KEYWORDS = ['ragging', 'harassment', 'fight', 'emergency', 'danger', 'stolen', 'threat', 'injury', 'severe', 'immediately', 'critical', 'urgent']
LOW_PRIORITY_KEYWORDS = ['minor', 'suggestion', 'request', 'inquiry', 'feedback', 'could be better']

POSITIVE_WORDS = ['good', 'helpful', 'thanks', 'resolved', 'appreciate', 'great']
NEGATIVE_WORDS = ['worst', 'bad', 'pathetic', 'terrible', 'broken', 'horrible', 'dirty', 'poor', 'useless', 'angry', 'fail', 'failed']

def analyze_complaint(title, description, category_hint=""):
    full_text = f"{title} {description}".lower()

    # 1. Department Detection
    matched_dept = "General Administration"
    dept_scores = {}
    for dept, keywords in DEPARTMENT_RULES.items():
        score = sum(1 for kw in keywords if re.search(r'\b' + re.escape(kw) + r'\b', full_text))
        dept_scores[dept] = score
    
    best_dept = max(dept_scores, key=dept_scores.get)
    if dept_scores[best_dept] > 0:
        matched_dept = best_dept
    elif category_hint:
        matched_dept = category_hint

    # 2. Priority Detection
    priority = "Medium"
    if any(re.search(r'\b' + re.escape(w) + r'\b', full_text) for w in HIGH_PRIORITY_KEYWORDS):
        priority = "High"
    elif any(re.search(r'\b' + re.escape(w) + r'\b', full_text) for w in LOW_PRIORITY_KEYWORDS):
        priority = "Low"

    # 3. Sentiment Analysis
    pos_score = sum(1 for w in POSITIVE_WORDS if re.search(r'\b' + re.escape(w) + r'\b', full_text))
    neg_score = sum(1 for w in NEGATIVE_WORDS if re.search(r'\b' + re.escape(w) + r'\b', full_text))
    
    if neg_score > pos_score:
        sentiment = "Negative"
    elif pos_score > neg_score:
        sentiment = "Positive"
    else:
        sentiment = "Neutral"

    # 4. Summary Generation
    clean_desc = re.sub(r'\s+', ' ', description).strip()
    summary = clean_desc[:120] + "..." if len(clean_desc) > 120 else clean_desc

    return {
        "status": "success",
        "predicted_category": matched_dept,
        "department": matched_dept,
        "priority": priority,
        "sentiment": sentiment,
        "summary": summary
    }

if __name__ == '__main__':
    title = sys.argv[1] if len(sys.argv) > 1 else ""
    description = sys.argv[2] if len(sys.argv) > 2 else ""
    category_hint = sys.argv[3] if len(sys.argv) > 3 else ""

    result = analyze_complaint(title, description, category_hint)
    print(json.dumps(result))
