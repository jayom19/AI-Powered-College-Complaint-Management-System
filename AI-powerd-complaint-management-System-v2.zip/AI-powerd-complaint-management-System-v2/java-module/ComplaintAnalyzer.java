import java.sql.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class ComplaintAnalyzer {
    // Database Configuration for Port 3307
    private static final String DB_URL = "jdbc:mysql://127.0.0.1:3307/college_complaint?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        System.out.println("Starting Java Complaint Analyzer via JDBC...");

        int totalCount = 0;
        int openCount = 0;
        int escalationAlertCount = 0;
        Map<String, Integer> departmentWorkload = new HashMap<>();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            System.out.println("Connected to MySQL successfully on Port 3307.");

            // 1. Total Complaints Count
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS total FROM complaints")) {
                if (rs.next()) {
                    totalCount = rs.getInt("total");
                }
            }

            // 2. Open Complaints Count
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS open_cases FROM complaints WHERE status IN ('Submitted', 'In Progress')")) {
                if (rs.next()) {
                    openCount = rs.getInt("open_cases");
                }
            }

            // 3. Escalation Alert Count (High Priority & Open)
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS alerts FROM complaints WHERE priority = 'High' AND status != 'Resolved'")) {
                if (rs.next()) {
                    escalationAlertCount = rs.getInt("alerts");
                }
            }

            // 4. Department-wise Open Complaint Workload
            String deptQuery = "SELECT COALESCE(department, 'Unassigned') AS dept, COUNT(*) AS workload " +
                               "FROM complaints WHERE status IN ('Submitted', 'In Progress') " +
                               "GROUP BY department";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(deptQuery)) {
                while (rs.next()) {
                    departmentWorkload.put(rs.getString("dept"), rs.getInt("workload"));
                }
            }

            // 5. Export to reports/java_analysis.csv
            File reportDir = new File("../reports");
            if (!reportDir.exists()) {
                reportDir.mkdirs();
            }

            File csvFile = new File("../reports/java_analysis.csv");
            try (PrintWriter writer = new PrintWriter(new FileWriter(csvFile))) {
                writer.println("METRIC,VALUE");
                writer.println("Total Complaints," + totalCount);
                writer.println("Open Complaints," + openCount);
                writer.println("Escalation Alerts," + escalationAlertCount);
                writer.println();
                writer.println("DEPARTMENT,OPEN_COUNT");
                for (Map.Entry<String, Integer> entry : departmentWorkload.entrySet()) {
                    writer.println(entry.getKey() + "," + entry.getValue());
                }
            }

            System.out.println("Java Complaint Analysis completed successfully.");
            System.out.println("Output exported to: " + csvFile.getAbsolutePath());

        } catch (SQLException e) {
            System.err.println("Database Error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Execution Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
