@echo off
cd /d "%~dp0"
echo ========================================================
echo Running Java Complaint Analyzer via JDBC
echo ========================================================
if not exist "bin" mkdir bin
javac -cp ".;mysql-connector-j-8.3.0.jar;lib/*" -d bin ComplaintAnalyzer.java
java -cp "bin;.;mysql-connector-j-8.3.0.jar;lib/*" ComplaintAnalyzer
echo Analysis Finished.
