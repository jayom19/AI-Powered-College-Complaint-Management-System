# AI-Powered College Complaint Management System

Complete, end-to-end college grievance redressal application integrating **PHP (Backend)**, **MySQL (Port 3307)**, **Python NLP (Scikit-Learn/TF-IDF Rule Engine)**, and **Java (JDBC Workload Reporting)** with automated 30-second live dashboard refresh.

---

## 📁 Complete Folder Structure
```text
C:\xampp\htdocs\AI-powerd-complaint-management-System\
│
├── config/
│   └── db.php                           (PDO Database Connection on Port 3307)
│
├── admin/
│   ├── register.php                     (New: Admin Registration Portal)
│   ├── login.php                        (Admin Portal Authentication with Schema Fallback)
│   ├── create_admin.php                 (One-click Admin Reset/Setup Utility)
│   ├── dashboard.php                    (Admin Dashboard with 30s Auto-Refresh)
│   ├── manage_complaint.php             (Complaint Status & AI Department Update)
│   ├── reports.php                      (AI Telemetry & Java CSV Workload Visualizer)
│   ├── users.php                        (Student Directory)
│   └── api_stats.php                    (JSON Endpoint for Real-time Polling)
│
├── student/
│   ├── dashboard.php                    (Student Grievance Overview & Tracking)
│   ├── submit_complaint.php             (Complaint Submission & Instant AI Trigger)
│   └── view_complaint.php               (Student Timeline & AI Diagnosis Card)
│
├── ai/
│   ├── analyze_complaint.py             (Python NLP: Department, Priority, Sentiment, Summary)
│   └── retry_pending_complaints.php     (PHP Automation Script for Task Scheduler)
│
├── java-module/
│   ├── ComplaintAnalyzer.java           (JDBC Program generating CSV Metrics)
│   └── run_analyzer.bat                 (Batch file to compile and execute Java Analyzer)
│
├── reports/
│   └── java_analysis.csv                (Output CSV parsed by admin/reports.php)
│
├── assets/
│   └── css/
│       └── style.css                    (Modern UI Styling)
│
├── uploads/                             (Directory for complaint attachments)
│
├── database.sql                         (Full Database Schema and Seed Data)
├── index.php                            (Landing Page with Student & Admin Register/Login)
├── login.php                            (Student Login)
├── register.php                         (Student Registration)
├── logout.php                           (Session Cleanup)
└── README.md                            (Documentation and Setup Guide)
```

---

## 🚀 Setup & Execution Guide

### 1. Database Setup
1. Open XAMPP and start **Apache** and **MySQL** (MySQL runs on port `3307`).
2. Go to phpMyAdmin (`http://localhost/phpmyadmin`).
3. Import `database.sql` into the `college_complaint` database.
4. Default Admin Login:
   - **Username:** `admin`
   - **Password:** `admin123`
   - Or register a new admin directly via **`admin/register.php`**.

### 2. Python AI Setup
Ensure Python is installed and accessible in Windows PATH:
```bash
python --version
```
Test the AI script from CMD:
```bash
python ai/analyze_complaint.py "Broken PC in lab" "The computer in Lab 2 won't boot up and display is broken" "IT & Network"
```

### 3. Java Module Setup
1. Place `mysql-connector-j-8.3.0.jar` in `java-module/`.
2. Run `java-module/run_analyzer.bat` to test CSV generation into `reports/java_analysis.csv`.

### 4. Windows Task Scheduler Setup
- Task name: `AI Complaint Retry`
  - Program: `C:\xampp\php\php.exe`
  - Arguments: `C:\xampp\htdocs\AI-powerd-complaint-management-System\ai\retry_pending_complaints.php`
  - Trigger: Every 5 minutes.
